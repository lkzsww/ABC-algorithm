function [Outp GlobalParams SectionNum] = ABCRiserPtOptConPro(RiserConf,PressNum,PSeal)
% the main procedure of artificial bee colony algorithm
% RiserNum - Number of risers
% PressNum - Number of pressure testings
% PSeal - Seal reliability
% GlobalParams - food source 
% SectionNum - The sequence for the pressure testing units
%%% Initialization %%%
RiserNum = length(RiserConf);
NP = 20;                        % Number of bees in the swarm (beeN)
FoodNumber = NP/2;              % Number of employed bees
Limit = 8;                      % Limit
maxCycle = 500;                 % Maximum number of iterations
Fnum = RiserNum - 1;            
PressNum = PressNum - 1;        
ProssRecall = zeros(maxCycle,FoodNumber);
ProssMaxRecall = zeros(maxCycle,1);
% Scout bee stage
Foods = cell(1,FoodNumber);     
for i=1:FoodNumber
    Foods{i} = initial(Fnum,PressNum);    
end
% Calculate the fitness value
for i=1:FoodNumber
    x = Foods{i};
    Fitness(i) = FitnessN(RiserConf,PressNum,x,PSeal);
end
trial = zeros(1,FoodNumber);
% Find the maximum 
BestInd = find(Fitness==max(Fitness));
BestInd = BestInd(end);
GlobalMax = Fitness(BestInd);
GlobalParams = Foods{BestInd};
% The begining of iteration 
iter = 1;
while(iter <= maxCycle)
    %%%% Employed bee stage %%%%
    for i=1:FoodNumber
        % Calculate the fitness value
        x = Foods{i};xFit = Fitness(i);
        [foodnew1] = localSearchStrategy1(x);
        [foodnew2] = localSearchStrategy2(x);
        Xnew1Fit = FitnessN(RiserConf,PressNum,foodnew1,PSeal);
        Xnew2Fit = FitnessN(RiserConf,PressNum,foodnew2,PSeal);        
        % Greedy criterion
        if Xnew2Fit > Xnew1Fit
            Xnew1Fit = Xnew2Fit;
            foodnew1 = foodnew2;
        end
        if Xnew1Fit > xFit
            Foods{i} = foodnew1;
            Fitness(i) = Xnew1Fit;
            trial(i)=0;
        else
            trial(i) = trial(i) + 1;
        end
    end
    %%%% The probability of one food source being chosen %%%%
    % Wheel selection method
    prob = Fitness/sum(Fitness);
    prob =cumsum(prob);
    %%%% Onlooker bee stage %%%%
    i = 1;
    t = 0; 
    while(t<FoodNumber)
        if (rand<prob(i))
            t = t+1;
            x = Foods{i};xFit = Fitness(i);
            [foodnew1,foodnew2] = localSearchStrategy3(x);
            Xnew1Fit = FitnessN(RiserConf,PressNum,foodnew1,PSeal);
            Xnew2Fit = FitnessN(RiserConf,PressNum,foodnew2,PSeal); 
            % Greedy criterion
            if Xnew2Fit > Xnew1Fit
                Xnew1Fit = Xnew2Fit;
                foodnew1 = foodnew2;
            end
            if Xnew1Fit > xFit
                Foods{i} = foodnew1;
                Fitness(i) = Xnew1Fit;
                trial(i)=0;
            else
                trial(i) = trial(i) + 1;
            end
        end
        i = i+1;
        if(i == FoodNumber +1)
            i =1;
        end
    end
    %%%% Find the best result until now %%%%
    ind = find(Fitness == max(Fitness));
    ind = ind(end);
    if (Fitness(ind) > GlobalMax)
        GlobalMax = Fitness(ind);
        GlobalParams = Foods{ind};
    end
    %%%% Onlooker bee stage %%%%
    for i=1:FoodNumber
        if trial(i) > Limit
            food_new = initial(Fnum,PressNum);
            FitnessSol = FitnessN(RiserConf,PressNum,food_new,PSeal);
            Foods{i} = food_new;
            Fitness(i) = FitnessSol;
            trial(i) = 0;
        end
    end
    %%% Record the Results
    ProssRecall(iter,:) = Fitness;
    ProssMaxRecall(iter) = GlobalMax;
    iter = iter+1;
end %while (iter <= maxCycle)
OptList=find(GlobalParams==1)+1;
OptList=[OptList;RiserNum];
SectionNum=ones(1,PressNum+1); 
SectionNum(1)=OptList(1);
for i=2:PressNum+1
    SectionNum(i)=OptList(i)-OptList(i-1);
end
GT = FITNESSTime(RiserConf,PressNum+1,GlobalParams,PSeal);
GR = FITNESSRisk(RiserNum,PressNum+1,GlobalParams,PSeal);
GF = 240-GR*GT;
Outp =[PressNum+1 GT GR GF];
lkhehe = 369;   






        
        


















