function R=FITNESSRisk(RiserNum,PressNum,x,PSeal)
% RISK ASSESSMENT MODEL
    PressPreNum=find(x==1)+1;
    PressPreNum=[PressPreNum;RiserNum];
    SectionNum=ones(1,PressNum); 
    SectionNum(1)=PressPreNum(1);
    for i=2:PressNum
        SectionNum(i)=PressPreNum(i)-PressPreNum(i-1);
    end
    R = 0;
    for i=1:PressNum
        R0 = PSeal^SectionNum(i);
        R1 = (R0-1)*log(R0);
        R = R + R1;
    end