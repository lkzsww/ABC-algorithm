function [TStatistics]=FITNESSTimeStatistics(RiserConf,PressNum,x,PSeal)
% TIME-EFFICIENCY EVALUATION MODEL for statistic analysis
% TStatistics = [TS TL TO T TB]
% TS is the time cost of the safety investment,namely, the time spend on security detection to reduce seal failure in connection;
% TL is the time cost of seal failure,namely, the time lost due to seal failure of a connection node during riser reentry;
% TO is the time cost of the best situation, namely, the optimal estimation of the operation time for riser reentry without seal failure;
% TB is the time cost of the safety benefit, namely, the cost-benefit measure of the safety investment from the perspective of the time cost.
% TF is the time cost of the fixed investment, namely the necessary time investment for riser landing and connection during reentry;
% T is the expected time for a riser system during the pressure testing and reentry process
% Basic data
    t1riser = 0.5;           % Reentry time for a slick joint ��h��
    t1buoyancy = 0.4;        % Reentry time for a buoyancy joint ��h��
    t5riser = 0.3;           % Retrieval time for a slick joint��h��
    t5buoyancy = 0.2;        % Retrieval time for a buoyancy joint ��h��
    t2=0.1;                      % Time for connection or disassembly ��h��
    t3=2.0;                      % Average time for a pressure testing��h��
    t4=0.25;                     % Downtime for detection and maintenance ��h��
    RiserNum = length(RiserConf);
    PressPreNum=find(x==1)+1;
    PressPreNum=[PressPreNum;RiserNum];
    T=0; TF = 0;
    for k=1:PressNum     
        if k==1
            Section = RiserConf(1:PressPreNum(k));
            b=length(Section)-1;
        else
            Section = RiserConf(PressPreNum(k-1)+1:PressPreNum(k));
            b=length(Section);
        end
        % 1 for slick joints; 0 for buoyancy joints
        a0 = length(find(Section==0));
        a1 = length(find(Section==1));
        TF0 = a0*t1buoyancy + a1*t1riser + b*t2;
        TK1 = TF0 + t3;
        TK2 = a0*t5buoyancy + a1*t5riser + b*t2 + t4;
        TK = (TK1 + TK2*(1-(PSeal.^b)))/(PSeal.^b);
        T=T+TK;
        
        TF = TF + TF0;
        TS = PressNum*t3;
        TO = TF + TS;
        TL = T - TO;
        TB = TS + TL;
        TStatistics = [TS TL TO T TB];
    end    