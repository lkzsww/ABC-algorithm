function G=FitnessN(RiserConf,PressNum,x,PSeal)
% Fitness function
    PressNum = PressNum+1;
    GT = FITNESSTime(RiserConf,PressNum,x,PSeal);
    RiserNum = length(RiserConf);
    GR = FITNESSRisk(RiserNum,PressNum,x,PSeal);
    G = 240-GT*GR;