function [food] = initial(Fnum,PressNum)
% Scout bee stage based on knapsack problem algorithm
    food=zeros(Fnum,1);
    index=zeros(PressNum,1);
    indexSet = 1:Fnum;
    indexnum=1;
    while indexnum<=PressNum
        temp = floor(rand * (Fnum - 1)) + 1;
        if max(size(find(index-temp)))==max(size(index))
            index(indexnum) = indexSet(temp);
            indexnum=indexnum+1;
        end 
    end
    food(index)=1;