function [foodnew] = localSearchStrategy1(x)
% The first strategy is a random search for a 1 and a 0, which are exchanged with each other.
    LocalOne = find(x==1);LocalZor = find(x==0); 
    MaxOne = length(LocalOne);MaxZor = length(LocalZor);
    RandOne = unidrnd(MaxOne);RandZor = unidrnd(MaxZor);
    SelectOne = LocalOne(RandOne);SelectZor = LocalZor(RandZor);
    x(SelectOne) = 0;x(SelectZor) = 1;
    foodnew = x;