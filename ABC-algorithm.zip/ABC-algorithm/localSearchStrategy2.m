function [foodnew] = localSearchStrategy2(x)
% The second strategy is a random search for a 1 and then exchanging it with an adjacent 0.
    LocalOne = find(x==1);
    MaxOne = length(LocalOne);
    RandOne = unidrnd(MaxOne);
    SelectOne = LocalOne(RandOne);
    while(1)
        if SelectOne ~= 1
            SelectZor = SelectOne - 1;
            if x(SelectZor) ==0
                x(SelectOne) = 0;x(SelectZor) = 1;foodnew = x;
                break;
            else
                SelectOne = SelectOne - 1;
            end
        else
            break;
        end
    end
    if SelectOne == 1
        while(1)
            SelectZor = SelectOne + 1;
            if x(SelectZor) == 0
                x(SelectOne) = 0;x(SelectZor) = 1;foodnew = x;
                break;
            else
                SelectOne = SelectOne + 1;
            end
        end
    end