function [foodnew1,foodnew2] = localSearchStrategy3(x)
% The third strategy is a random search a continuous piece of code and move it one step up or down.
    tempx = x;
    LocalZor = find(tempx==0); 
    MaxZor = length(LocalZor);
    RandZor = unidrnd(MaxZor);
    SelectZor1 = LocalZor(RandZor);    
    tempx(SelectZor1) = 1;
    LocalZor = find(tempx==0); 
    RandZor = unidrnd(MaxZor-1);
    SelectZor2 = LocalZor(RandZor);
    if SelectZor2<SelectZor1
        tempnum = SelectZor2;SelectZor2 =SelectZor1;SelectZor1 = tempnum;        
    end
    % foodnew1 : move it one step up
    tempx = x;
    tempx1 = tempx(1:SelectZor1-1);
    tempx2 = tempx(SelectZor1+1:SelectZor2);
    tempx3 = tempx(SelectZor2+1:end);
    foodnew1 =[tempx1;tempx2;0;tempx3];    
    % foodnew2 :move it one step down
    tempx = x;
    tempx1 = tempx(1:SelectZor1);
    tempx2 = tempx(SelectZor1+1:SelectZor2-1);
    tempx3 = tempx(SelectZor2+1:end);
    foodnew2 =[tempx1;0;tempx2;tempx3];