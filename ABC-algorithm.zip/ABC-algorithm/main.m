% An Optimization Approach for Pressure Testing During Reentry Operation of Deepwater Drilling Riser System
clc;clear;
% 1000 ft riser configuration
RiserNum = 133;
% 1 for slick joints; 0 for buoyancy joints
RiserConf = zeros(1,RiserNum-7);      
RiserConf(5:6:end) = 1;
RiserConf(6:6:end) = 1;
RiserConf1 = ones(1,7);
RiserConf = [RiserConf1 RiserConf]; % from bottom up

PSeal = 0.98; % Seal reliability (p) of the connection nodes between the riser joints
for PressNum=14:14 % PressNum for number of pressure testings
    [Outp X SectionNum] = ABCRiserPtOptConPro(RiserConf,PressNum,PSeal);
    disp(Outp); 
    % Outp =[PressNum,Expected time(T),Risk entropy(R),fitness(F)];
    % X - food source 
    % SectionNum - the sequence for the pressure testing units
    [TStatistics]=FITNESSTimeStatistics(RiserConf,PressNum,X,PSeal);
    disp(TStatistics); % TStatistics=[TS TL TO T TB]
end
lkhehe = 369;
% TS -  the time cost of the safety investment
% TL -  the time cost of seal failure
% TO -  the time cost of the best situation
% T -  the expected time for a riser system during the pressure testing and reentry process
% TB -  the time cost of the safety benefit












